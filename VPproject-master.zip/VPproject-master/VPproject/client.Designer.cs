﻿namespace VPproject
{
    partial class client
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.deactivate_btn = new System.Windows.Forms.Button();
            this.invdob_pic = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.invdob_lbl = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.update_btn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.fname_txt = new System.Windows.Forms.TextBox();
            this.invphone_pic = new System.Windows.Forms.PictureBox();
            this.lname_txt = new System.Windows.Forms.TextBox();
            this.invphone_lbl = new System.Windows.Forms.Label();
            this.email_txt = new System.Windows.Forms.TextBox();
            this.invemail_pic = new System.Windows.Forms.PictureBox();
            this.invlname_pic = new System.Windows.Forms.PictureBox();
            this.dob_pick = new System.Windows.Forms.DateTimePicker();
            this.invfname_pic = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.phone_txt = new System.Windows.Forms.TextBox();
            this.invemail_lbl = new System.Windows.Forms.Label();
            this.invfnamelbl = new System.Windows.Forms.Label();
            this.invlnamelbl = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.logout_btn = new System.Windows.Forms.Button();
            this.mycourses_btn = new System.Windows.Forms.Button();
            this.myacc_btn = new System.Windows.Forms.Button();
            this.bookc_btn = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.invdob_pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.invphone_pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.invemail_pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.invlname_pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.invfname_pic)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightBlue;
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.deactivate_btn);
            this.panel1.Controls.Add(this.invdob_pic);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.invdob_lbl);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.update_btn);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.fname_txt);
            this.panel1.Controls.Add(this.invphone_pic);
            this.panel1.Controls.Add(this.lname_txt);
            this.panel1.Controls.Add(this.invphone_lbl);
            this.panel1.Controls.Add(this.email_txt);
            this.panel1.Controls.Add(this.invemail_pic);
            this.panel1.Controls.Add(this.invlname_pic);
            this.panel1.Controls.Add(this.dob_pick);
            this.panel1.Controls.Add(this.invfname_pic);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.phone_txt);
            this.panel1.Controls.Add(this.invemail_lbl);
            this.panel1.Controls.Add(this.invfnamelbl);
            this.panel1.Controls.Add(this.invlnamelbl);
            this.panel1.Location = new System.Drawing.Point(53, 45);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(817, 385);
            this.panel1.TabIndex = 36;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Calibri", 30F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.label8.Location = new System.Drawing.Point(35, 31);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(218, 49);
            this.label8.TabIndex = 35;
            this.label8.Text = "My Account";
            // 
            // deactivate_btn
            // 
            this.deactivate_btn.BackColor = System.Drawing.Color.DarkRed;
            this.deactivate_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.deactivate_btn.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.deactivate_btn.ForeColor = System.Drawing.SystemColors.Window;
            this.deactivate_btn.Location = new System.Drawing.Point(583, 333);
            this.deactivate_btn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.deactivate_btn.Name = "deactivate_btn";
            this.deactivate_btn.Size = new System.Drawing.Size(191, 29);
            this.deactivate_btn.TabIndex = 34;
            this.deactivate_btn.TabStop = false;
            this.deactivate_btn.Text = "Deactivate Account";
            this.deactivate_btn.UseVisualStyleBackColor = false;
            this.deactivate_btn.Click += new System.EventHandler(this.deactivate_btn_Click);
            // 
            // invdob_pic
            // 
            this.invdob_pic.BackgroundImage = global::VPproject.Properties.Resources.ki85qL9kT;
            this.invdob_pic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.invdob_pic.Location = new System.Drawing.Point(582, 191);
            this.invdob_pic.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.invdob_pic.Name = "invdob_pic";
            this.invdob_pic.Size = new System.Drawing.Size(13, 11);
            this.invdob_pic.TabIndex = 33;
            this.invdob_pic.TabStop = false;
            this.invdob_pic.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.label1.Location = new System.Drawing.Point(35, 112);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 27);
            this.label1.TabIndex = 0;
            this.label1.Text = "First Name";
            // 
            // invdob_lbl
            // 
            this.invdob_lbl.AutoSize = true;
            this.invdob_lbl.BackColor = System.Drawing.Color.Transparent;
            this.invdob_lbl.Font = new System.Drawing.Font("Calibri", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.invdob_lbl.ForeColor = System.Drawing.Color.Red;
            this.invdob_lbl.Location = new System.Drawing.Point(601, 191);
            this.invdob_lbl.Name = "invdob_lbl";
            this.invdob_lbl.Size = new System.Drawing.Size(116, 14);
            this.invdob_lbl.TabIndex = 32;
            this.invdob_lbl.Text = "User must be an adult";
            this.invdob_lbl.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.label2.Location = new System.Drawing.Point(412, 112);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 27);
            this.label2.TabIndex = 1;
            this.label2.Text = "Last Name";
            // 
            // update_btn
            // 
            this.update_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.update_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.update_btn.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.update_btn.ForeColor = System.Drawing.SystemColors.Window;
            this.update_btn.Location = new System.Drawing.Point(35, 333);
            this.update_btn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.update_btn.Name = "update_btn";
            this.update_btn.Size = new System.Drawing.Size(191, 29);
            this.update_btn.TabIndex = 30;
            this.update_btn.TabStop = false;
            this.update_btn.Text = "Update Information";
            this.update_btn.UseVisualStyleBackColor = false;
            this.update_btn.Click += new System.EventHandler(this.update_btn_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.label3.Location = new System.Drawing.Point(53, 156);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 27);
            this.label3.TabIndex = 2;
            this.label3.Text = "Email";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.label6.Location = new System.Drawing.Point(411, 162);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(134, 27);
            this.label6.TabIndex = 5;
            this.label6.Text = "Date Of Birth";
            // 
            // fname_txt
            // 
            this.fname_txt.BackColor = System.Drawing.SystemColors.Window;
            this.fname_txt.Location = new System.Drawing.Point(207, 112);
            this.fname_txt.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.fname_txt.Name = "fname_txt";
            this.fname_txt.Size = new System.Drawing.Size(140, 23);
            this.fname_txt.TabIndex = 6;
            this.fname_txt.TabStop = false;
            // 
            // invphone_pic
            // 
            this.invphone_pic.BackgroundImage = global::VPproject.Properties.Resources.ki85qL9kT;
            this.invphone_pic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.invphone_pic.Location = new System.Drawing.Point(207, 236);
            this.invphone_pic.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.invphone_pic.Name = "invphone_pic";
            this.invphone_pic.Size = new System.Drawing.Size(13, 11);
            this.invphone_pic.TabIndex = 25;
            this.invphone_pic.TabStop = false;
            this.invphone_pic.Visible = false;
            // 
            // lname_txt
            // 
            this.lname_txt.Location = new System.Drawing.Point(583, 118);
            this.lname_txt.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lname_txt.Name = "lname_txt";
            this.lname_txt.Size = new System.Drawing.Size(138, 23);
            this.lname_txt.TabIndex = 7;
            this.lname_txt.TabStop = false;
            // 
            // invphone_lbl
            // 
            this.invphone_lbl.AutoSize = true;
            this.invphone_lbl.BackColor = System.Drawing.Color.Transparent;
            this.invphone_lbl.Font = new System.Drawing.Font("Calibri", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.invphone_lbl.ForeColor = System.Drawing.Color.Red;
            this.invphone_lbl.Location = new System.Drawing.Point(226, 236);
            this.invphone_lbl.Name = "invphone_lbl";
            this.invphone_lbl.Size = new System.Drawing.Size(116, 14);
            this.invphone_lbl.TabIndex = 24;
            this.invphone_lbl.Text = "Invalid Phone Number";
            this.invphone_lbl.Visible = false;
            // 
            // email_txt
            // 
            this.email_txt.Enabled = false;
            this.email_txt.Location = new System.Drawing.Point(207, 160);
            this.email_txt.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.email_txt.Name = "email_txt";
            this.email_txt.Size = new System.Drawing.Size(141, 23);
            this.email_txt.TabIndex = 8;
            this.email_txt.TabStop = false;
            // 
            // invemail_pic
            // 
            this.invemail_pic.BackgroundImage = global::VPproject.Properties.Resources.ki85qL9kT;
            this.invemail_pic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.invemail_pic.Location = new System.Drawing.Point(207, 184);
            this.invemail_pic.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.invemail_pic.Name = "invemail_pic";
            this.invemail_pic.Size = new System.Drawing.Size(13, 11);
            this.invemail_pic.TabIndex = 21;
            this.invemail_pic.TabStop = false;
            this.invemail_pic.Visible = false;
            // 
            // invlname_pic
            // 
            this.invlname_pic.BackgroundImage = global::VPproject.Properties.Resources.ki85qL9kT;
            this.invlname_pic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.invlname_pic.Location = new System.Drawing.Point(583, 142);
            this.invlname_pic.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.invlname_pic.Name = "invlname_pic";
            this.invlname_pic.Size = new System.Drawing.Size(13, 11);
            this.invlname_pic.TabIndex = 20;
            this.invlname_pic.TabStop = false;
            this.invlname_pic.Visible = false;
            // 
            // dob_pick
            // 
            this.dob_pick.Location = new System.Drawing.Point(583, 166);
            this.dob_pick.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dob_pick.MaxDate = new System.DateTime(2003, 12, 31, 0, 0, 0, 0);
            this.dob_pick.MinDate = new System.DateTime(1930, 1, 1, 0, 0, 0, 0);
            this.dob_pick.Name = "dob_pick";
            this.dob_pick.Size = new System.Drawing.Size(217, 23);
            this.dob_pick.TabIndex = 11;
            this.dob_pick.TabStop = false;
            this.dob_pick.Value = new System.DateTime(2002, 12, 31, 0, 0, 0, 0);
            // 
            // invfname_pic
            // 
            this.invfname_pic.BackgroundImage = global::VPproject.Properties.Resources.ki85qL9kT;
            this.invfname_pic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.invfname_pic.Location = new System.Drawing.Point(207, 134);
            this.invfname_pic.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.invfname_pic.Name = "invfname_pic";
            this.invfname_pic.Size = new System.Drawing.Size(13, 11);
            this.invfname_pic.TabIndex = 19;
            this.invfname_pic.TabStop = false;
            this.invfname_pic.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.label7.Location = new System.Drawing.Point(35, 207);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(151, 27);
            this.label7.TabIndex = 12;
            this.label7.Text = "Phone Number";
            // 
            // phone_txt
            // 
            this.phone_txt.Location = new System.Drawing.Point(207, 211);
            this.phone_txt.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.phone_txt.MaxLength = 10;
            this.phone_txt.Name = "phone_txt";
            this.phone_txt.Size = new System.Drawing.Size(141, 23);
            this.phone_txt.TabIndex = 13;
            this.phone_txt.TabStop = false;
            // 
            // invemail_lbl
            // 
            this.invemail_lbl.AutoSize = true;
            this.invemail_lbl.BackColor = System.Drawing.Color.Transparent;
            this.invemail_lbl.Font = new System.Drawing.Font("Calibri", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.invemail_lbl.ForeColor = System.Drawing.Color.Red;
            this.invemail_lbl.Location = new System.Drawing.Point(225, 183);
            this.invemail_lbl.Name = "invemail_lbl";
            this.invemail_lbl.Size = new System.Drawing.Size(71, 14);
            this.invemail_lbl.TabIndex = 16;
            this.invemail_lbl.Text = "Invalid Email";
            this.invemail_lbl.Visible = false;
            // 
            // invfnamelbl
            // 
            this.invfnamelbl.AutoSize = true;
            this.invfnamelbl.BackColor = System.Drawing.Color.Transparent;
            this.invfnamelbl.Font = new System.Drawing.Font("Calibri", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.invfnamelbl.ForeColor = System.Drawing.Color.Red;
            this.invfnamelbl.Location = new System.Drawing.Point(225, 134);
            this.invfnamelbl.Name = "invfnamelbl";
            this.invfnamelbl.Size = new System.Drawing.Size(98, 14);
            this.invfnamelbl.TabIndex = 14;
            this.invfnamelbl.Text = "Invalid First Name";
            this.invfnamelbl.Visible = false;
            // 
            // invlnamelbl
            // 
            this.invlnamelbl.AutoSize = true;
            this.invlnamelbl.BackColor = System.Drawing.Color.Transparent;
            this.invlnamelbl.Font = new System.Drawing.Font("Calibri", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.invlnamelbl.ForeColor = System.Drawing.Color.Red;
            this.invlnamelbl.Location = new System.Drawing.Point(602, 140);
            this.invlnamelbl.Name = "invlnamelbl";
            this.invlnamelbl.Size = new System.Drawing.Size(96, 14);
            this.invlnamelbl.TabIndex = 15;
            this.invlnamelbl.Text = "Invalid Last Name";
            this.invlnamelbl.Visible = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.panel2.Controls.Add(this.logout_btn);
            this.panel2.Controls.Add(this.mycourses_btn);
            this.panel2.Controls.Add(this.myacc_btn);
            this.panel2.Controls.Add(this.bookc_btn);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Font = new System.Drawing.Font("Calibri", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.panel2.ForeColor = System.Drawing.Color.Transparent;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(949, 23);
            this.panel2.TabIndex = 37;
            // 
            // logout_btn
            // 
            this.logout_btn.BackColor = System.Drawing.Color.Transparent;
            this.logout_btn.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.logout_btn.FlatAppearance.BorderSize = 0;
            this.logout_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logout_btn.ForeColor = System.Drawing.SystemColors.Window;
            this.logout_btn.Location = new System.Drawing.Point(870, 0);
            this.logout_btn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.logout_btn.Name = "logout_btn";
            this.logout_btn.Size = new System.Drawing.Size(76, 23);
            this.logout_btn.TabIndex = 6;
            this.logout_btn.TabStop = false;
            this.logout_btn.Text = "Log Out";
            this.logout_btn.UseVisualStyleBackColor = false;
            this.logout_btn.Click += new System.EventHandler(this.button1_Click);
            // 
            // mycourses_btn
            // 
            this.mycourses_btn.BackColor = System.Drawing.Color.Transparent;
            this.mycourses_btn.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.mycourses_btn.FlatAppearance.BorderSize = 0;
            this.mycourses_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mycourses_btn.ForeColor = System.Drawing.SystemColors.Window;
            this.mycourses_btn.Location = new System.Drawing.Point(151, 2);
            this.mycourses_btn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.mycourses_btn.Name = "mycourses_btn";
            this.mycourses_btn.Size = new System.Drawing.Size(93, 22);
            this.mycourses_btn.TabIndex = 5;
            this.mycourses_btn.TabStop = false;
            this.mycourses_btn.Text = "My Courses";
            this.mycourses_btn.UseVisualStyleBackColor = false;
            this.mycourses_btn.Click += new System.EventHandler(this.mycourses_btn_Click);
            // 
            // myacc_btn
            // 
            this.myacc_btn.BackColor = System.Drawing.Color.Transparent;
            this.myacc_btn.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.myacc_btn.FlatAppearance.BorderSize = 0;
            this.myacc_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.myacc_btn.ForeColor = System.Drawing.SystemColors.Window;
            this.myacc_btn.Location = new System.Drawing.Point(3, 1);
            this.myacc_btn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.myacc_btn.Name = "myacc_btn";
            this.myacc_btn.Size = new System.Drawing.Size(144, 22);
            this.myacc_btn.TabIndex = 4;
            this.myacc_btn.TabStop = false;
            this.myacc_btn.Text = "Manage Account";
            this.myacc_btn.UseVisualStyleBackColor = false;
            this.myacc_btn.Click += new System.EventHandler(this.myacc_btn_Click);
            // 
            // bookc_btn
            // 
            this.bookc_btn.BackColor = System.Drawing.Color.Transparent;
            this.bookc_btn.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.bookc_btn.FlatAppearance.BorderSize = 0;
            this.bookc_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bookc_btn.ForeColor = System.Drawing.SystemColors.Window;
            this.bookc_btn.Location = new System.Drawing.Point(251, 2);
            this.bookc_btn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.bookc_btn.Name = "bookc_btn";
            this.bookc_btn.Size = new System.Drawing.Size(108, 22);
            this.bookc_btn.TabIndex = 3;
            this.bookc_btn.TabStop = false;
            this.bookc_btn.Text = "Book a Course";
            this.bookc_btn.UseVisualStyleBackColor = false;
            this.bookc_btn.Click += new System.EventHandler(this.bookc_btn_Click);
            // 
            // client
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.ClientSize = new System.Drawing.Size(949, 473);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "client";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "client";
            this.Load += new System.EventHandler(this.client_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.invdob_pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.invphone_pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.invemail_pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.invlname_pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.invfname_pic)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Label label8;
        private Button deactivate_btn;
        private PictureBox invdob_pic;
        private Label label1;
        private Label invdob_lbl;
        private Label label2;
        private Button update_btn;
        private Label label3;
        private Label label6;
        private TextBox fname_txt;
        private PictureBox invphone_pic;
        private TextBox lname_txt;
        private Label invphone_lbl;
        private TextBox email_txt;
        private PictureBox invemail_pic;
        private PictureBox invlname_pic;
        private DateTimePicker dob_pick;
        private PictureBox invfname_pic;
        private Label label7;
        private TextBox phone_txt;
        private Label invemail_lbl;
        private Label invfnamelbl;
        private Label invlnamelbl;
        private Panel panel1;
        private Panel panel2;
        private Button logout_btn;
        private Button mycourses_btn;
        private Button myacc_btn;
        private Button bookc_btn;
    }
}
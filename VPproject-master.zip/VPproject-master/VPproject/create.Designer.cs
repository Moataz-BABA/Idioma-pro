﻿namespace VPproject
{
    partial class create
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(create));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.fname_txt = new System.Windows.Forms.TextBox();
            this.lname_txt = new System.Windows.Forms.TextBox();
            this.email_txt = new System.Windows.Forms.TextBox();
            this.pass_txt = new System.Windows.Forms.TextBox();
            this.pass2_txt = new System.Windows.Forms.TextBox();
            this.dob_pick = new System.Windows.Forms.DateTimePicker();
            this.phone_txt = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.invfnamelbl = new System.Windows.Forms.Label();
            this.invlnamelbl = new System.Windows.Forms.Label();
            this.invemail_lbl = new System.Windows.Forms.Label();
            this.invpass2_lbl = new System.Windows.Forms.Label();
            this.invfname_pic = new System.Windows.Forms.PictureBox();
            this.invlname_pic = new System.Windows.Forms.PictureBox();
            this.invemail_pic = new System.Windows.Forms.PictureBox();
            this.invpass2_pic = new System.Windows.Forms.PictureBox();
            this.invphone_pic = new System.Windows.Forms.PictureBox();
            this.invphone_lbl = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.invpass_pic = new System.Windows.Forms.PictureBox();
            this.invpass_lbl = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.invdob_lbl = new System.Windows.Forms.Label();
            this.invdob_pic = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.invfname_pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.invlname_pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.invemail_pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.invpass2_pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.invphone_pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.invpass_pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.invdob_pic)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.label1.Location = new System.Drawing.Point(77, 85);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 35);
            this.label1.TabIndex = 0;
            this.label1.Text = "First Name";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.label2.Location = new System.Drawing.Point(475, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(139, 35);
            this.label2.TabIndex = 1;
            this.label2.Text = "Last Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.label3.Location = new System.Drawing.Point(97, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 35);
            this.label3.TabIndex = 2;
            this.label3.Text = "Email";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.label4.Location = new System.Drawing.Point(77, 206);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(128, 35);
            this.label4.TabIndex = 3;
            this.label4.Text = "Password";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.label5.Location = new System.Drawing.Point(50, 281);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(218, 35);
            this.label5.TabIndex = 4;
            this.label5.Text = "Repeat Password";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.label6.Location = new System.Drawing.Point(475, 206);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(170, 35);
            this.label6.TabIndex = 5;
            this.label6.Text = "Date Of Birth";
            // 
            // fname_txt
            // 
            this.fname_txt.BackColor = System.Drawing.SystemColors.Window;
            this.fname_txt.Location = new System.Drawing.Point(273, 86);
            this.fname_txt.Name = "fname_txt";
            this.fname_txt.Size = new System.Drawing.Size(160, 27);
            this.fname_txt.TabIndex = 6;
            this.fname_txt.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lname_txt
            // 
            this.lname_txt.Location = new System.Drawing.Point(671, 85);
            this.lname_txt.Name = "lname_txt";
            this.lname_txt.Size = new System.Drawing.Size(157, 27);
            this.lname_txt.TabIndex = 7;
            this.lname_txt.TextChanged += new System.EventHandler(this.lname_txt_TextChanged);
            // 
            // email_txt
            // 
            this.email_txt.Location = new System.Drawing.Point(273, 150);
            this.email_txt.Name = "email_txt";
            this.email_txt.Size = new System.Drawing.Size(161, 27);
            this.email_txt.TabIndex = 8;
            this.email_txt.TextChanged += new System.EventHandler(this.email_txt_TextChanged);
            // 
            // pass_txt
            // 
            this.pass_txt.Location = new System.Drawing.Point(274, 215);
            this.pass_txt.Name = "pass_txt";
            this.pass_txt.PasswordChar = '*';
            this.pass_txt.Size = new System.Drawing.Size(160, 27);
            this.pass_txt.TabIndex = 9;
            this.pass_txt.TextChanged += new System.EventHandler(this.pass_txt_TextChanged);
            // 
            // pass2_txt
            // 
            this.pass2_txt.Location = new System.Drawing.Point(274, 289);
            this.pass2_txt.Name = "pass2_txt";
            this.pass2_txt.PasswordChar = '*';
            this.pass2_txt.Size = new System.Drawing.Size(160, 27);
            this.pass2_txt.TabIndex = 10;
            this.pass2_txt.TextChanged += new System.EventHandler(this.pass2_txt_TextChanged);
            // 
            // dob_pick
            // 
            this.dob_pick.Location = new System.Drawing.Point(672, 211);
            this.dob_pick.MaxDate = new System.DateTime(2003, 12, 31, 0, 0, 0, 0);
            this.dob_pick.MinDate = new System.DateTime(1930, 1, 1, 0, 0, 0, 0);
            this.dob_pick.Name = "dob_pick";
            this.dob_pick.Size = new System.Drawing.Size(247, 27);
            this.dob_pick.TabIndex = 11;
            this.dob_pick.Value = new System.DateTime(2002, 12, 31, 0, 0, 0, 0);
            this.dob_pick.ValueChanged += new System.EventHandler(this.dob_pick_ValueChanged);
            // 
            // phone_txt
            // 
            this.phone_txt.Location = new System.Drawing.Point(671, 151);
            this.phone_txt.MaxLength = 10;
            this.phone_txt.Name = "phone_txt";
            this.phone_txt.Size = new System.Drawing.Size(157, 27);
            this.phone_txt.TabIndex = 13;
            this.phone_txt.TextChanged += new System.EventHandler(this.passport_txt_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.label7.Location = new System.Drawing.Point(475, 144);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(190, 35);
            this.label7.TabIndex = 12;
            this.label7.Text = "Phone Number";
            // 
            // invfnamelbl
            // 
            this.invfnamelbl.AutoSize = true;
            this.invfnamelbl.BackColor = System.Drawing.Color.Transparent;
            this.invfnamelbl.Font = new System.Drawing.Font("Calibri", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.invfnamelbl.ForeColor = System.Drawing.Color.Red;
            this.invfnamelbl.Location = new System.Drawing.Point(295, 116);
            this.invfnamelbl.Name = "invfnamelbl";
            this.invfnamelbl.Size = new System.Drawing.Size(121, 18);
            this.invfnamelbl.TabIndex = 14;
            this.invfnamelbl.Text = "Invalid First Name";
            this.invfnamelbl.Visible = false;
            this.invfnamelbl.Click += new System.EventHandler(this.invfnamelbl_Click);
            // 
            // invlnamelbl
            // 
            this.invlnamelbl.AutoSize = true;
            this.invlnamelbl.BackColor = System.Drawing.Color.Transparent;
            this.invlnamelbl.Font = new System.Drawing.Font("Calibri", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.invlnamelbl.ForeColor = System.Drawing.Color.Red;
            this.invlnamelbl.Location = new System.Drawing.Point(692, 115);
            this.invlnamelbl.Name = "invlnamelbl";
            this.invlnamelbl.Size = new System.Drawing.Size(119, 18);
            this.invlnamelbl.TabIndex = 15;
            this.invlnamelbl.Text = "Invalid Last Name";
            this.invlnamelbl.Visible = false;
            // 
            // invemail_lbl
            // 
            this.invemail_lbl.AutoSize = true;
            this.invemail_lbl.BackColor = System.Drawing.Color.Transparent;
            this.invemail_lbl.Font = new System.Drawing.Font("Calibri", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.invemail_lbl.ForeColor = System.Drawing.Color.Red;
            this.invemail_lbl.Location = new System.Drawing.Point(294, 180);
            this.invemail_lbl.Name = "invemail_lbl";
            this.invemail_lbl.Size = new System.Drawing.Size(89, 18);
            this.invemail_lbl.TabIndex = 16;
            this.invemail_lbl.Text = "Invalid Email";
            this.invemail_lbl.Visible = false;
            // 
            // invpass2_lbl
            // 
            this.invpass2_lbl.AutoSize = true;
            this.invpass2_lbl.BackColor = System.Drawing.Color.Transparent;
            this.invpass2_lbl.Font = new System.Drawing.Font("Calibri", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.invpass2_lbl.ForeColor = System.Drawing.Color.Red;
            this.invpass2_lbl.Location = new System.Drawing.Point(295, 319);
            this.invpass2_lbl.Name = "invpass2_lbl";
            this.invpass2_lbl.Size = new System.Drawing.Size(159, 18);
            this.invpass2_lbl.TabIndex = 18;
            this.invpass2_lbl.Text = "Passwords do not match";
            this.invpass2_lbl.Visible = false;
            // 
            // invfname_pic
            // 
            this.invfname_pic.BackgroundImage = global::VPproject.Properties.Resources.ki85qL9kT;
            this.invfname_pic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.invfname_pic.Location = new System.Drawing.Point(274, 122);
            this.invfname_pic.Name = "invfname_pic";
            this.invfname_pic.Size = new System.Drawing.Size(15, 15);
            this.invfname_pic.TabIndex = 19;
            this.invfname_pic.TabStop = false;
            this.invfname_pic.Visible = false;
            this.invfname_pic.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // invlname_pic
            // 
            this.invlname_pic.BackgroundImage = global::VPproject.Properties.Resources.ki85qL9kT;
            this.invlname_pic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.invlname_pic.Location = new System.Drawing.Point(671, 118);
            this.invlname_pic.Name = "invlname_pic";
            this.invlname_pic.Size = new System.Drawing.Size(15, 15);
            this.invlname_pic.TabIndex = 20;
            this.invlname_pic.TabStop = false;
            this.invlname_pic.Visible = false;
            // 
            // invemail_pic
            // 
            this.invemail_pic.BackgroundImage = global::VPproject.Properties.Resources.ki85qL9kT;
            this.invemail_pic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.invemail_pic.Location = new System.Drawing.Point(273, 181);
            this.invemail_pic.Name = "invemail_pic";
            this.invemail_pic.Size = new System.Drawing.Size(15, 15);
            this.invemail_pic.TabIndex = 21;
            this.invemail_pic.TabStop = false;
            this.invemail_pic.Visible = false;
            // 
            // invpass2_pic
            // 
            this.invpass2_pic.BackgroundImage = global::VPproject.Properties.Resources.ki85qL9kT;
            this.invpass2_pic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.invpass2_pic.Location = new System.Drawing.Point(273, 322);
            this.invpass2_pic.Name = "invpass2_pic";
            this.invpass2_pic.Size = new System.Drawing.Size(15, 15);
            this.invpass2_pic.TabIndex = 23;
            this.invpass2_pic.TabStop = false;
            this.invpass2_pic.Visible = false;
            // 
            // invphone_pic
            // 
            this.invphone_pic.BackgroundImage = global::VPproject.Properties.Resources.ki85qL9kT;
            this.invphone_pic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.invphone_pic.Location = new System.Drawing.Point(671, 182);
            this.invphone_pic.Name = "invphone_pic";
            this.invphone_pic.Size = new System.Drawing.Size(15, 15);
            this.invphone_pic.TabIndex = 25;
            this.invphone_pic.TabStop = false;
            this.invphone_pic.Visible = false;
            // 
            // invphone_lbl
            // 
            this.invphone_lbl.AutoSize = true;
            this.invphone_lbl.BackColor = System.Drawing.Color.Transparent;
            this.invphone_lbl.Font = new System.Drawing.Font("Calibri", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.invphone_lbl.ForeColor = System.Drawing.Color.Red;
            this.invphone_lbl.Location = new System.Drawing.Point(692, 181);
            this.invphone_lbl.Name = "invphone_lbl";
            this.invphone_lbl.Size = new System.Drawing.Size(146, 18);
            this.invphone_lbl.TabIndex = 24;
            this.invphone_lbl.Text = "Invalid Phone Number";
            this.invphone_lbl.Visible = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.button6.ForeColor = System.Drawing.SystemColors.Window;
            this.button6.Location = new System.Drawing.Point(786, 366);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(90, 33);
            this.button6.TabIndex = 26;
            this.button6.TabStop = false;
            this.button6.Text = "Sign Up";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // invpass_pic
            // 
            this.invpass_pic.BackgroundImage = global::VPproject.Properties.Resources.ki85qL9kT;
            this.invpass_pic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.invpass_pic.Location = new System.Drawing.Point(274, 247);
            this.invpass_pic.Name = "invpass_pic";
            this.invpass_pic.Size = new System.Drawing.Size(15, 15);
            this.invpass_pic.TabIndex = 27;
            this.invpass_pic.TabStop = false;
            this.invpass_pic.Visible = false;
            // 
            // invpass_lbl
            // 
            this.invpass_lbl.AutoSize = true;
            this.invpass_lbl.BackColor = System.Drawing.Color.Transparent;
            this.invpass_lbl.Font = new System.Drawing.Font("Calibri", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.invpass_lbl.ForeColor = System.Drawing.Color.Red;
            this.invpass_lbl.Location = new System.Drawing.Point(295, 246);
            this.invpass_lbl.Name = "invpass_lbl";
            this.invpass_lbl.Size = new System.Drawing.Size(157, 18);
            this.invpass_lbl.TabIndex = 28;
            this.invpass_lbl.Text = "Please Enter a password";
            this.invpass_lbl.Visible = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Calibri", 30F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.label8.Location = new System.Drawing.Point(45, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(184, 61);
            this.label8.TabIndex = 29;
            this.label8.Text = "Sign Up";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.button1.ForeColor = System.Drawing.SystemColors.Window;
            this.button1.Location = new System.Drawing.Point(50, 366);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(90, 33);
            this.button1.TabIndex = 30;
            this.button1.TabStop = false;
            this.button1.Text = "Back";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // invdob_lbl
            // 
            this.invdob_lbl.AutoSize = true;
            this.invdob_lbl.BackColor = System.Drawing.Color.Transparent;
            this.invdob_lbl.Font = new System.Drawing.Font("Calibri", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.invdob_lbl.ForeColor = System.Drawing.Color.Red;
            this.invdob_lbl.Location = new System.Drawing.Point(692, 244);
            this.invdob_lbl.Name = "invdob_lbl";
            this.invdob_lbl.Size = new System.Drawing.Size(143, 18);
            this.invdob_lbl.TabIndex = 32;
            this.invdob_lbl.Text = "User must be an adult";
            this.invdob_lbl.Visible = false;
            // 
            // invdob_pic
            // 
            this.invdob_pic.BackgroundImage = global::VPproject.Properties.Resources.ki85qL9kT;
            this.invdob_pic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.invdob_pic.Location = new System.Drawing.Point(671, 244);
            this.invdob_pic.Name = "invdob_pic";
            this.invdob_pic.Size = new System.Drawing.Size(15, 15);
            this.invdob_pic.TabIndex = 33;
            this.invdob_pic.TabStop = false;
            this.invdob_pic.Visible = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightBlue;
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.invdob_pic);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.invdob_lbl);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.invpass_lbl);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.invpass_pic);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.fname_txt);
            this.panel1.Controls.Add(this.invphone_pic);
            this.panel1.Controls.Add(this.lname_txt);
            this.panel1.Controls.Add(this.invphone_lbl);
            this.panel1.Controls.Add(this.email_txt);
            this.panel1.Controls.Add(this.invpass2_pic);
            this.panel1.Controls.Add(this.pass_txt);
            this.panel1.Controls.Add(this.invemail_pic);
            this.panel1.Controls.Add(this.pass2_txt);
            this.panel1.Controls.Add(this.invlname_pic);
            this.panel1.Controls.Add(this.dob_pick);
            this.panel1.Controls.Add(this.invfname_pic);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.invpass2_lbl);
            this.panel1.Controls.Add(this.phone_txt);
            this.panel1.Controls.Add(this.invemail_lbl);
            this.panel1.Controls.Add(this.invfnamelbl);
            this.panel1.Controls.Add(this.invlnamelbl);
            this.panel1.Location = new System.Drawing.Point(118, 61);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(933, 420);
            this.panel1.TabIndex = 34;
            // 
            // create
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1163, 526);
            this.Controls.Add(this.panel1);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "create";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "create";
            this.Load += new System.EventHandler(this.create_Load);
            ((System.ComponentModel.ISupportInitialize)(this.invfname_pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.invlname_pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.invemail_pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.invpass2_pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.invphone_pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.invpass_pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.invdob_pic)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox fname_txt;
        private TextBox lname_txt;
        private TextBox email_txt;
        private TextBox pass_txt;
        private TextBox pass2_txt;
        private DateTimePicker dob_pick;
        private TextBox phone_txt;
        private Label label7;
        private Label invfnamelbl;
        private Label invlnamelbl;
        private Label invemail_lbl;
        private Label invpass2_lbl;
        private PictureBox invfname_pic;
        private PictureBox invlname_pic;
        private PictureBox invemail_pic;
        private PictureBox invpass2_pic;
        private PictureBox invphone_pic;
        private Label invphone_lbl;
        private Button button6;
        private PictureBox invpass_pic;
        private Label invpass_lbl;
        private Label label8;
        private Button button1;
        private Label invdob_lbl;
        private PictureBox invdob_pic;
        private Panel panel1;
    }
}
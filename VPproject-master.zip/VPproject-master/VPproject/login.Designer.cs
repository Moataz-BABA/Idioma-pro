﻿namespace VPproject
{

    partial class login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.invinfo_lbl = new System.Windows.Forms.Label();
            this.email_txt = new System.Windows.Forms.TextBox();
            this.invinfo_pic = new System.Windows.Forms.PictureBox();
            this.pass_txt = new System.Windows.Forms.TextBox();
            this.login_btn = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.invinfo_pic)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.LightBlue;
            this.groupBox2.Controls.Add(this.linkLabel2);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.invinfo_lbl);
            this.groupBox2.Controls.Add(this.email_txt);
            this.groupBox2.Controls.Add(this.invinfo_pic);
            this.groupBox2.Controls.Add(this.pass_txt);
            this.groupBox2.Controls.Add(this.login_btn);
            this.groupBox2.Location = new System.Drawing.Point(286, 51);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(442, 399);
            this.groupBox2.TabIndex = 60;
            this.groupBox2.TabStop = false;
            this.groupBox2.Tag = "";
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.DisabledLinkColor = System.Drawing.Color.Black;
            this.linkLabel2.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.linkLabel2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.linkLabel2.LinkColor = System.Drawing.Color.Black;
            this.linkLabel2.Location = new System.Drawing.Point(267, 365);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(60, 18);
            this.linkLabel2.TabIndex = 59;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "Sign Up!";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(112, 365);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(149, 18);
            this.label2.TabIndex = 58;
            this.label2.Text = "Dont have an account?";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Calibri", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.label5.Location = new System.Drawing.Point(41, 125);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 35);
            this.label5.TabIndex = 32;
            this.label5.Text = "Email";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Calibri", 30F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.label6.Location = new System.Drawing.Point(133, 23);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(150, 61);
            this.label6.TabIndex = 57;
            this.label6.Text = "Log In";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Calibri", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.label7.Location = new System.Drawing.Point(42, 189);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(128, 35);
            this.label7.TabIndex = 33;
            this.label7.Text = "Password";
            // 
            // invinfo_lbl
            // 
            this.invinfo_lbl.AutoSize = true;
            this.invinfo_lbl.BackColor = System.Drawing.Color.Transparent;
            this.invinfo_lbl.Font = new System.Drawing.Font("Calibri", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.invinfo_lbl.ForeColor = System.Drawing.Color.Red;
            this.invinfo_lbl.Location = new System.Drawing.Point(70, 252);
            this.invinfo_lbl.Name = "invinfo_lbl";
            this.invinfo_lbl.Size = new System.Drawing.Size(168, 18);
            this.invinfo_lbl.TabIndex = 56;
            this.invinfo_lbl.Text = "Wrong Email or Password";
            this.invinfo_lbl.Visible = false;
            // 
            // email_txt
            // 
            this.email_txt.Location = new System.Drawing.Point(174, 133);
            this.email_txt.Name = "email_txt";
            this.email_txt.Size = new System.Drawing.Size(237, 27);
            this.email_txt.TabIndex = 38;
            // 
            // invinfo_pic
            // 
            this.invinfo_pic.BackgroundImage = global::VPproject.Properties.Resources.ki85qL9kT;
            this.invinfo_pic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.invinfo_pic.Location = new System.Drawing.Point(49, 253);
            this.invinfo_pic.Name = "invinfo_pic";
            this.invinfo_pic.Size = new System.Drawing.Size(15, 15);
            this.invinfo_pic.TabIndex = 55;
            this.invinfo_pic.TabStop = false;
            this.invinfo_pic.Visible = false;
            // 
            // pass_txt
            // 
            this.pass_txt.Location = new System.Drawing.Point(175, 197);
            this.pass_txt.Name = "pass_txt";
            this.pass_txt.PasswordChar = '*';
            this.pass_txt.Size = new System.Drawing.Size(236, 27);
            this.pass_txt.TabIndex = 39;
            // 
            // login_btn
            // 
            this.login_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.login_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.login_btn.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.login_btn.ForeColor = System.Drawing.SystemColors.Window;
            this.login_btn.Location = new System.Drawing.Point(174, 305);
            this.login_btn.Name = "login_btn";
            this.login_btn.Size = new System.Drawing.Size(90, 41);
            this.login_btn.TabIndex = 54;
            this.login_btn.TabStop = false;
            this.login_btn.Text = "Log in";
            this.login_btn.UseVisualStyleBackColor = false;
            this.login_btn.Click += new System.EventHandler(this.login_btn_Click);
            // 
            // login
            // 
            this.AcceptButton = this.login_btn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::VPproject.Properties.Resources.lecs;
            this.ClientSize = new System.Drawing.Size(981, 499);
            this.Controls.Add(this.groupBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "login";
            this.Load += new System.EventHandler(this.login_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.invinfo_pic)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox groupBox2;
        private LinkLabel linkLabel2;
        private Label label2;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label invinfo_lbl;
        private TextBox email_txt;
        private PictureBox invinfo_pic;
        private TextBox pass_txt;
        private Button login_btn;
    }
}
﻿namespace VPproject
{
    partial class payment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.invccn_pic = new System.Windows.Forms.PictureBox();
            this.invccn_lbl = new System.Windows.Forms.Label();
            this.invname_pic = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.logout_btn = new System.Windows.Forms.Button();
            this.invname_lbl = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.invcvv_pic = new System.Windows.Forms.PictureBox();
            this.invcvv_lbl = new System.Windows.Forms.Label();
            this.cvv = new System.Windows.Forms.TextBox();
            this.chname = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.ccn = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.ctotal_txt = new System.Windows.Forms.TextBox();
            this.Course = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lvl_txt = new System.Windows.Forms.TextBox();
            this.total_txt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.invccn_pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.invname_pic)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.invcvv_pic)).BeginInit();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // invccn_pic
            // 
            this.invccn_pic.BackgroundImage = global::VPproject.Properties.Resources.ki85qL9kT;
            this.invccn_pic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.invccn_pic.Location = new System.Drawing.Point(294, 106);
            this.invccn_pic.Name = "invccn_pic";
            this.invccn_pic.Size = new System.Drawing.Size(15, 15);
            this.invccn_pic.TabIndex = 55;
            this.invccn_pic.TabStop = false;
            this.invccn_pic.Visible = false;
            // 
            // invccn_lbl
            // 
            this.invccn_lbl.AutoSize = true;
            this.invccn_lbl.BackColor = System.Drawing.Color.Transparent;
            this.invccn_lbl.Font = new System.Drawing.Font("Calibri", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.invccn_lbl.ForeColor = System.Drawing.Color.Red;
            this.invccn_lbl.Location = new System.Drawing.Point(314, 106);
            this.invccn_lbl.Name = "invccn_lbl";
            this.invccn_lbl.Size = new System.Drawing.Size(152, 18);
            this.invccn_lbl.TabIndex = 54;
            this.invccn_lbl.Text = "Please Enter CCNumber";
            this.invccn_lbl.Visible = false;
            // 
            // invname_pic
            // 
            this.invname_pic.BackgroundImage = global::VPproject.Properties.Resources.ki85qL9kT;
            this.invname_pic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.invname_pic.Location = new System.Drawing.Point(294, 38);
            this.invname_pic.Name = "invname_pic";
            this.invname_pic.Size = new System.Drawing.Size(15, 15);
            this.invname_pic.TabIndex = 53;
            this.invname_pic.TabStop = false;
            this.invname_pic.Visible = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.panel3.Controls.Add(this.logout_btn);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Font = new System.Drawing.Font("Calibri", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.panel3.ForeColor = System.Drawing.Color.Transparent;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(991, 27);
            this.panel3.TabIndex = 50;
            // 
            // logout_btn
            // 
            this.logout_btn.BackColor = System.Drawing.Color.Transparent;
            this.logout_btn.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.logout_btn.FlatAppearance.BorderSize = 0;
            this.logout_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logout_btn.ForeColor = System.Drawing.SystemColors.Window;
            this.logout_btn.Location = new System.Drawing.Point(899, -3);
            this.logout_btn.Name = "logout_btn";
            this.logout_btn.Size = new System.Drawing.Size(87, 35);
            this.logout_btn.TabIndex = 6;
            this.logout_btn.TabStop = false;
            this.logout_btn.Text = "Log Out";
            this.logout_btn.UseVisualStyleBackColor = false;
            this.logout_btn.Click += new System.EventHandler(this.logout_btn_Click);
            // 
            // invname_lbl
            // 
            this.invname_lbl.AutoSize = true;
            this.invname_lbl.BackColor = System.Drawing.Color.Transparent;
            this.invname_lbl.Font = new System.Drawing.Font("Calibri", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.invname_lbl.ForeColor = System.Drawing.Color.Red;
            this.invname_lbl.Location = new System.Drawing.Point(314, 38);
            this.invname_lbl.Name = "invname_lbl";
            this.invname_lbl.Size = new System.Drawing.Size(134, 18);
            this.invname_lbl.TabIndex = 52;
            this.invname_lbl.Text = "Please Enter a Name";
            this.invname_lbl.Visible = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.button1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(607, 629);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(196, 39);
            this.button1.TabIndex = 48;
            this.button1.Text = "Book My Course!";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.label4.Location = new System.Drawing.Point(98, 69);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(179, 35);
            this.label4.TabIndex = 43;
            this.label4.Text = "Card Number:";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Transparent;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel4.Controls.Add(this.panel1);
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Location = new System.Drawing.Point(178, 95);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(625, 527);
            this.panel4.TabIndex = 51;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.numericUpDown2);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.invname_lbl);
            this.panel1.Controls.Add(this.numericUpDown1);
            this.panel1.Controls.Add(this.invname_pic);
            this.panel1.Controls.Add(this.invcvv_pic);
            this.panel1.Controls.Add(this.invccn_lbl);
            this.panel1.Controls.Add(this.invcvv_lbl);
            this.panel1.Controls.Add(this.invccn_pic);
            this.panel1.Controls.Add(this.cvv);
            this.panel1.Controls.Add(this.chname);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.ccn);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(27, 14);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(568, 259);
            this.panel1.TabIndex = 72;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.label7.Location = new System.Drawing.Point(20, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(257, 35);
            this.label7.TabIndex = 41;
            this.label7.Text = "Card Holder\'s Name:";
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Location = new System.Drawing.Point(456, 143);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            2030,
            0,
            0,
            0});
            this.numericUpDown2.Minimum = new decimal(new int[] {
            2023,
            0,
            0,
            0});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(61, 27);
            this.numericUpDown2.TabIndex = 71;
            this.numericUpDown2.TabStop = false;
            this.numericUpDown2.Value = new decimal(new int[] {
            2023,
            0,
            0,
            0});
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.label6.Location = new System.Drawing.Point(119, 135);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(158, 35);
            this.label6.TabIndex = 39;
            this.label6.Text = "Expiry Date:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label13.Location = new System.Drawing.Point(413, 147);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(38, 18);
            this.label13.TabIndex = 70;
            this.label13.Text = "Year:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(294, 146);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 18);
            this.label12.TabIndex = 12;
            this.label12.Text = "Month:";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(352, 143);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(42, 27);
            this.numericUpDown1.TabIndex = 69;
            this.numericUpDown1.TabStop = false;
            this.numericUpDown1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // invcvv_pic
            // 
            this.invcvv_pic.BackgroundImage = global::VPproject.Properties.Resources.ki85qL9kT;
            this.invcvv_pic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.invcvv_pic.Location = new System.Drawing.Point(294, 230);
            this.invcvv_pic.Name = "invcvv_pic";
            this.invcvv_pic.Size = new System.Drawing.Size(15, 15);
            this.invcvv_pic.TabIndex = 66;
            this.invcvv_pic.TabStop = false;
            this.invcvv_pic.Visible = false;
            // 
            // invcvv_lbl
            // 
            this.invcvv_lbl.AutoSize = true;
            this.invcvv_lbl.BackColor = System.Drawing.Color.Transparent;
            this.invcvv_lbl.Font = new System.Drawing.Font("Calibri", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.invcvv_lbl.ForeColor = System.Drawing.Color.Red;
            this.invcvv_lbl.Location = new System.Drawing.Point(314, 230);
            this.invcvv_lbl.Name = "invcvv_lbl";
            this.invcvv_lbl.Size = new System.Drawing.Size(112, 18);
            this.invcvv_lbl.TabIndex = 65;
            this.invcvv_lbl.Text = "Please Enter CVV";
            this.invcvv_lbl.Visible = false;
            // 
            // cvv
            // 
            this.cvv.Location = new System.Drawing.Point(296, 200);
            this.cvv.MaxLength = 4;
            this.cvv.Name = "cvv";
            this.cvv.Size = new System.Drawing.Size(47, 27);
            this.cvv.TabIndex = 64;
            this.cvv.TextChanged += new System.EventHandler(this.ccv_TextChanged);
            // 
            // chname
            // 
            this.chname.Location = new System.Drawing.Point(296, 8);
            this.chname.Name = "chname";
            this.chname.Size = new System.Drawing.Size(221, 27);
            this.chname.TabIndex = 56;
            this.chname.TextChanged += new System.EventHandler(this.chname_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.label9.Location = new System.Drawing.Point(208, 193);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(71, 35);
            this.label9.TabIndex = 63;
            this.label9.Text = "CVV:";
            // 
            // ccn
            // 
            this.ccn.Location = new System.Drawing.Point(296, 76);
            this.ccn.Name = "ccn";
            this.ccn.Size = new System.Drawing.Size(221, 27);
            this.ccn.TabIndex = 57;
            this.ccn.TextChanged += new System.EventHandler(this.ccn_TextChanged);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(395, 142);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(22, 25);
            this.label2.TabIndex = 60;
            this.label2.Text = "/";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Transparent;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel5.Controls.Add(this.ctotal_txt);
            this.panel5.Controls.Add(this.Course);
            this.panel5.Controls.Add(this.label3);
            this.panel5.Controls.Add(this.lvl_txt);
            this.panel5.Controls.Add(this.total_txt);
            this.panel5.Controls.Add(this.label5);
            this.panel5.Location = new System.Drawing.Point(250, 290);
            this.panel5.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(108, 217);
            this.panel5.TabIndex = 58;
            // 
            // ctotal_txt
            // 
            this.ctotal_txt.Location = new System.Drawing.Point(2, 45);
            this.ctotal_txt.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ctotal_txt.Name = "ctotal_txt";
            this.ctotal_txt.ReadOnly = true;
            this.ctotal_txt.Size = new System.Drawing.Size(100, 27);
            this.ctotal_txt.TabIndex = 5;
            // 
            // Course
            // 
            this.Course.AutoSize = true;
            this.Course.BackColor = System.Drawing.Color.Transparent;
            this.Course.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Course.Location = new System.Drawing.Point(2, 17);
            this.Course.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Course.Name = "Course";
            this.Course.Size = new System.Drawing.Size(84, 18);
            this.Course.TabIndex = 6;
            this.Course.Text = "Course Total";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(2, 84);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 18);
            this.label3.TabIndex = 7;
            this.label3.Text = "Level Total";
            // 
            // lvl_txt
            // 
            this.lvl_txt.Location = new System.Drawing.Point(2, 105);
            this.lvl_txt.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.lvl_txt.Name = "lvl_txt";
            this.lvl_txt.ReadOnly = true;
            this.lvl_txt.Size = new System.Drawing.Size(100, 27);
            this.lvl_txt.TabIndex = 8;
            // 
            // total_txt
            // 
            this.total_txt.Location = new System.Drawing.Point(2, 165);
            this.total_txt.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.total_txt.Name = "total_txt";
            this.total_txt.PlaceholderText = "Hours x Total";
            this.total_txt.ReadOnly = true;
            this.total_txt.Size = new System.Drawing.Size(100, 27);
            this.total_txt.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(2, 144);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 18);
            this.label5.TabIndex = 11;
            this.label5.Text = "Net Total";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.button2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(178, 629);
            this.button2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(107, 39);
            this.button2.TabIndex = 52;
            this.button2.Text = "Back";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Calibri", 30F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(76)))), ((int)(((byte)(164)))));
            this.label1.Location = new System.Drawing.Point(395, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(211, 61);
            this.label1.TabIndex = 53;
            this.label1.Text = "Payment";
            // 
            // payment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.ClientSize = new System.Drawing.Size(991, 690);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "payment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "payment";
            this.Load += new System.EventHandler(this.payment_Load);
            ((System.ComponentModel.ISupportInitialize)(this.invccn_pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.invname_pic)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.invcvv_pic)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox invccn_pic;
        private Label invccn_lbl;
        private PictureBox invname_pic;
        private Panel panel3;
        private Button logout_btn;
        private Label invname_lbl;
        private Button button1;
        private Label label4;
        private Panel panel4;
        private TextBox ccn;
        private TextBox chname;
        private Label label7;
        private Label label6;
        private Button button2;
        private Panel panel5;
        private TextBox ctotal_txt;
        private Label Course;
        private Label label3;
        private TextBox lvl_txt;
        private TextBox total_txt;
        private Label label5;
        private TextBox cvv;
        private Label label9;
        private Label label2;
        private Label label1;
        private NumericUpDown numericUpDown2;
        private Label label13;
        private Label label12;
        private NumericUpDown numericUpDown1;
        private PictureBox invcvv_pic;
        private Label invcvv_lbl;
        private Panel panel1;
    }
}